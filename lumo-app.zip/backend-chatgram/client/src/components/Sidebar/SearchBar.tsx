'use client'
import React, { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { useChat } from '@/store/chatStore'
import { setToken } from '@/lib/api'
import { disconnectSocket } from '@/lib/socket'
import { LogoutIcon, MoonIcon, SearchIcon } from '@/utils/icons'
import UserAvatar from '../UserAvatar'

export const SearchBar = () => {
  const router = useRouter()
  const me = useChat((s) => s.me)
  const search = useChat((s) => s.search)
  const setSearch = useChat((s) => s.setSearch)
  const [dark, setDark] = useState(false)

  useEffect(() => {
    try {
      const saved = localStorage.getItem('chatgram_theme')
      if (saved === 'dark') setDark(true)
    } catch {}
  }, [])

  useEffect(() => {
    document.documentElement.setAttribute('data-theme', dark ? 'dark' : 'light')
    try {
      localStorage.setItem('chatgram_theme', dark ? 'dark' : 'light')
    } catch {}
  }, [dark])

  function logout() {
    setToken(null)
    disconnectSocket()
    router.push('/')
  }

  return (
    <div className="flex items-center gap-2 p-3">
      {me && <UserAvatar imageId={me.imageId} size={44} online />}
      <div className="relative flex-1 min-w-0">
        <input
          type="search"
          placeholder="Поиск"
          aria-label="Поиск по людям"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="input input-bordered w-full rounded-full pl-10 bg-base-200"
        />
        <div className="w-5 h-5 absolute top-1/2 left-4 -translate-y-1/2 opacity-60 pointer-events-none">
          <SearchIcon />
        </div>
      </div>
      <button className="btn btn-ghost btn-circle btn-sm" onClick={() => setDark(!dark)} aria-label="Сменить тему">
        <MoonIcon />
      </button>
      <button className="btn btn-ghost btn-circle btn-sm" onClick={logout} aria-label="Выйти">
        <LogoutIcon />
      </button>
    </div>
  )
}
