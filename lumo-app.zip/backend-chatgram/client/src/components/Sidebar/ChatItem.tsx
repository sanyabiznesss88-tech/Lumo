'use client'
import React from 'react'
import { useChat } from '@/store/chatStore'
import { openChat } from '@/lib/actions'
import { listTime } from '@/lib/format'
import { Conversation } from '@/types'
import UserAvatar from '../UserAvatar'

const ChatItem = ({ conv }: { conv: Conversation }) => {
  const { user, last, unread } = conv
  const selected = useChat((s) => s.selectedId === user._id)
  const online = useChat((s) => !!s.online[user._id])
  const typing = useChat((s) => !!s.typing[user._id])

  return (
    <li>
      <button
        onClick={() => openChat(user._id)}
        className={`w-full flex items-center gap-3 p-3 rounded-xl text-left hover:bg-base-200 ${selected ? 'bg-base-200' : ''}`}
      >
        <UserAvatar imageId={user.imageId} size={52} online={online} />
        <div className="flex-1 min-w-0">
          <div className="flex justify-between gap-2">
            <h3 className="font-semibold truncate">{user.name}</h3>
            {last && <span className="text-xs opacity-60 flex-none">{listTime(last.createdAt)}</span>}
          </div>
          <div className="flex justify-between gap-2 items-center">
            <p className={`text-sm truncate ${typing ? 'text-primary' : 'opacity-60'}`}>
              {typing ? 'печатает…' : last ? `${last.mine ? 'Вы: ' : ''}${last.text}` : 'Напиши первым'}
            </p>
            {unread > 0 && <span className="badge badge-primary badge-sm flex-none">{unread}</span>}
          </div>
        </div>
      </button>
    </li>
  )
}

export default ChatItem
