'use client'
import React from 'react'
import { useChat } from '@/store/chatStore'
import ChatItem from './ChatItem'

const ChatList = () => {
  const conversations = useChat((s) => s.conversations)
  const search = useChat((s) => s.search).trim().toLowerCase()
  const list = search ? conversations.filter((c) => c.user.name.toLowerCase().includes(search)) : conversations

  if (list.length === 0) {
    return (
      <p className="p-6 text-center text-sm opacity-60">
        {search ? 'Никого не найдено' : 'Пока никого нет. Позови друга зарегистрироваться.'}
      </p>
    )
  }

  return (
    <ul className="flex-1 overflow-y-auto px-2 pb-2">
      {list.map((c) => (
        <ChatItem key={c.user._id} conv={c} />
      ))}
    </ul>
  )
}

export default ChatList
