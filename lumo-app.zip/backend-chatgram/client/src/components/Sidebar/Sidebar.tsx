'use client'
import React from 'react'
import { useChat } from '@/store/chatStore'
import { SearchBar } from './SearchBar'
import ChatList from './ChatList'

const Sidebar = () => {
  const selectedId = useChat((s) => s.selectedId)
  return (
    // На телефоне при открытом чате список скрыт
    <aside
      className={`${selectedId ? 'hidden md:flex' : 'flex'} w-full md:w-80 lg:w-96 flex-none flex-col h-full border-r border-base-300 bg-base-100`}
    >
      <SearchBar />
      <ChatList />
    </aside>
  )
}

export default Sidebar
