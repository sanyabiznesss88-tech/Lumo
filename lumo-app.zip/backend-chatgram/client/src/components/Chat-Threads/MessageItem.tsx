import React from 'react'
import { timeOf } from '@/lib/format'
import { Message } from '@/types'

const MessageItem = ({ message, mine }: { message: Message; mine: boolean }) => {
  return (
    <div className={`chat ${mine ? 'chat-end' : 'chat-start'}`}>
      <div className={`chat-bubble whitespace-pre-wrap break-words ${mine ? 'chat-bubble-primary' : ''}`}>
        {message.text}
      </div>
      <div className="chat-footer text-xs opacity-60">
        {timeOf(message.createdAt)}
        {mine && <span className={message.readAt ? 'text-primary' : ''}> {message.readAt ? '✓✓' : '✓'}</span>}
      </div>
    </div>
  )
}

export default MessageItem
