'use client'
import React, { useEffect, useRef } from 'react'
import { useChat } from '@/store/chatStore'
import { dayLabel, isSameDay } from '@/lib/format'
import MessageItem from './MessageItem'

function MessageList() {
  const messages = useChat((s) => s.messages)
  const meId = useChat((s) => s.me?._id)
  const loading = useChat((s) => s.loadingMessages)
  const selectedId = useChat((s) => s.selectedId)
  const endRef = useRef<HTMLDivElement>(null)

  // Прокрутка вниз при открытии чата и при новых сообщениях
  useEffect(() => {
    endRef.current?.scrollIntoView({ block: 'end' })
  }, [messages.length, selectedId])

  return (
    <div className="flex-1 min-h-0 overflow-y-auto px-3 py-2 no-scrollbar">
      <div className="max-w-3xl mx-auto">
        {loading && <div className="text-center py-6"><span className="loading loading-dots" /></div>}
        {!loading && messages.length === 0 && (
          <p className="text-center my-6 text-sm opacity-70">Сообщений пока нет. Напиши первым.</p>
        )}
        {messages.map((m, i) => (
          <React.Fragment key={m._id}>
            {(i === 0 || !isSameDay(messages[i - 1].createdAt, m.createdAt)) && (
              <div className="text-center my-3">
                <span className="badge badge-neutral">{dayLabel(m.createdAt)}</span>
              </div>
            )}
            <MessageItem message={m} mine={m.from === meId} />
          </React.Fragment>
        ))}
        <div ref={endRef} />
      </div>
    </div>
  )
}

export default MessageList
