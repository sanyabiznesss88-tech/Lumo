'use client'
import React from 'react'
import { useChat } from '@/store/chatStore'
import TopBar from './TopBar'
import MessageList from './MessageList'
import MessageInp from './MessageInput'

const Messages = () => {
  const selectedId = useChat((s) => s.selectedId)
  return (
    <section className={`${selectedId ? 'flex' : 'hidden md:flex'} flex-1 min-w-0 flex-col h-full bg-image bg-cover`}>
      {selectedId ? (
        <>
          <TopBar />
          <MessageList />
          <MessageInp key={selectedId} />
        </>
      ) : (
        <p className="m-auto bg-base-100 px-4 py-2 rounded-full text-sm opacity-80">
          Выбери, с кем хочешь поговорить
        </p>
      )}
    </section>
  )
}

export default Messages
