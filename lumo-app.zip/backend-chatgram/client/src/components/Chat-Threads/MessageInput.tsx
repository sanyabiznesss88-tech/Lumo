'use client'
import React, { useEffect, useRef, useState } from 'react'
import dynamic from 'next/dynamic'
import { useChat } from '@/store/chatStore'
import { getSocket } from '@/lib/socket'
import { sendMessage } from '@/lib/actions'
import { SendMsIcon, SmileFaceIcon } from '@/utils/icons'

const Picker = dynamic(() => import('emoji-picker-react'), { ssr: false })

function MessageInp() {
  const selectedId = useChat((s) => s.selectedId)
  const [text, setText] = useState('')
  const [showEmojis, setShowEmojis] = useState(false)
  const [error, setError] = useState('')
  const typingRef = useRef(false)
  const timerRef = useRef<ReturnType<typeof setTimeout> | undefined>(undefined)

  function emitTyping(isTyping: boolean) {
    typingRef.current = isTyping
    getSocket()?.emit('typing', { to: selectedId, isTyping })
  }

  // При смене чата (компонент пересоздаётся по key) гасим «печатает…»
  useEffect(() => {
    return () => {
      clearTimeout(timerRef.current)
      if (typingRef.current) emitTyping(false)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  function onChange(value: string) {
    setText(value)
    if (!typingRef.current) emitTyping(true)
    clearTimeout(timerRef.current)
    timerRef.current = setTimeout(() => emitTyping(false), 2000)
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault()
    const value = text.trim()
    if (!value || !selectedId) return
    setText('')
    setShowEmojis(false)
    clearTimeout(timerRef.current)
    emitTyping(false)
    const res = await sendMessage(selectedId, value)
    if (res.ok) setError('')
    else {
      // Возвращаем текст, чтобы его не пришлось печатать заново
      setText(value)
      setError(res.error || 'Не удалось отправить')
    }
  }

  return (
    <form className="relative bg-base-100 border-t border-base-300 p-3" onSubmit={submit}>
      {error && <p className="text-error text-sm mb-2">{error}</p>}
      <div className="relative max-w-3xl mx-auto">
        <button
          type="button"
          onClick={() => setShowEmojis(!showEmojis)}
          className="absolute top-1/2 left-3 -translate-y-1/2"
          aria-label="Эмодзи"
        >
          <SmileFaceIcon />
        </button>
        <input
          type="text"
          placeholder="Сообщение"
          aria-label="Сообщение"
          className="input input-bordered w-full pl-12 pr-12"
          value={text}
          onChange={(e) => onChange(e.target.value)}
          maxLength={4000}
          autoComplete="off"
        />
        <button
          type="submit"
          className="absolute top-1/2 right-3 -translate-y-1/2 text-primary"
          aria-label="Отправить"
        >
          <SendMsIcon />
        </button>
        {showEmojis && (
          <div className="absolute bottom-full left-0 mb-2 z-20">
            <Picker
              width={300}
              height={380}
              onEmojiClick={(emoji: { emoji: string }) => setText((t) => t + emoji.emoji)}
            />
          </div>
        )}
      </div>
    </form>
  )
}

export default MessageInp
