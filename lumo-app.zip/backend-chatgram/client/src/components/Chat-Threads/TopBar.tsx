'use client'
import React from 'react'
import { useChat } from '@/store/chatStore'
import { closeChat } from '@/lib/actions'
import { lastSeenText } from '@/lib/format'
import { BackIcon } from '@/utils/icons'
import UserAvatar from '../UserAvatar'

const TopBar = () => {
  const selectedId = useChat((s) => s.selectedId)
  const user = useChat((s) => s.conversations.find((c) => c.user._id === s.selectedId)?.user)
  const online = useChat((s) => (selectedId ? !!s.online[selectedId] : false))
  const typing = useChat((s) => (selectedId ? !!s.typing[selectedId] : false))
  const seen = useChat((s) => (selectedId ? s.lastSeen[selectedId] : undefined))

  if (!user) return null
  const status = typing ? 'печатает…' : online ? 'в сети' : lastSeenText(seen ?? user.lastSeen)

  return (
    <header className="flex items-center gap-3 px-3 py-2 bg-base-100 border-b border-base-300">
      <button className="btn btn-ghost btn-circle btn-sm md:hidden" onClick={closeChat} aria-label="Назад">
        <BackIcon />
      </button>
      <UserAvatar imageId={user.imageId} size={44} online={online} />
      <div className="min-w-0">
        <h2 className="font-semibold truncate">{user.name}</h2>
        <p className={`text-sm ${typing || online ? 'text-primary' : 'opacity-60'}`}>{status}</p>
      </div>
    </header>
  )
}

export default TopBar
