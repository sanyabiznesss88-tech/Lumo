'use client'
import React from 'react'
import UserAvatar from '../UserAvatar'

export const AVATAR_COUNT = 6

// Нажатие на аватар листает варианты
const Avatar = ({ avatarId, setAvatarId }: { avatarId: number; setAvatarId: (id: number) => void }) => {
  return (
    <button
      type="button"
      onClick={() => setAvatarId((avatarId + 1) % AVATAR_COUNT)}
      className="mx-auto tooltip"
      data-tip="Нажми, чтобы выбрать другой аватар"
      aria-label="Выбрать другой аватар"
    >
      <UserAvatar imageId={avatarId} size={96} />
    </button>
  )
}

export default Avatar
