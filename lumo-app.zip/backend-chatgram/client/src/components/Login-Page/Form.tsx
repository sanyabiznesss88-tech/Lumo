'use client'
import React, { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import Avatar from './Avatar'
import { api, getToken, setToken } from '@/lib/api'
import { Me } from '@/types'

type Mode = 'login' | 'register'

function Form() {
  const router = useRouter()
  const [mode, setMode] = useState<Mode>('login')
  const [avatarId, setAvatarId] = useState(1)
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)

  // Если уже входили, сразу открываем чаты (токен проверит сама страница чатов)
  useEffect(() => {
    if (getToken()) router.replace('/chat')
  }, [router])

  async function submit(e: React.FormEvent) {
    e.preventDefault()
    setError('')
    setBusy(true)
    try {
      const body = mode === 'register' ? { name, email, password, imageId: avatarId } : { email, password }
      const res = await api<{ token: string; user: Me }>(`/auth/${mode}`, { method: 'POST', body })
      setToken(res.token)
      router.push('/chat')
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Что-то пошло не так')
      setBusy(false)
    }
  }

  return (
    <form onSubmit={submit} className="flex flex-col gap-4 p-6 shadow-lg">
      <h1 className="text-2xl font-semibold text-center">{mode === 'login' ? 'Вход в Chatgram' : 'Регистрация'}</h1>

      {mode === 'register' && <Avatar avatarId={avatarId} setAvatarId={setAvatarId} />}

      {mode === 'register' && (
        <label className="form-control w-full">
          <span className="label-text mb-1">Имя</span>
          <input
            type="text"
            className="input input-bordered w-full"
            placeholder="Как тебя зовут"
            value={name}
            onChange={(e) => setName(e.target.value)}
            minLength={2}
            maxLength={32}
            required
            autoComplete="nickname"
          />
        </label>
      )}

      <label className="form-control w-full">
        <span className="label-text mb-1">Email</span>
        <input
          type="email"
          className="input input-bordered w-full"
          placeholder="you@example.com"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
          autoComplete="email"
        />
      </label>

      <label className="form-control w-full">
        <span className="label-text mb-1">Пароль</span>
        <input
          type="password"
          className="input input-bordered w-full"
          placeholder="Минимум 6 символов"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          minLength={6}
          maxLength={72}
          required
          autoComplete={mode === 'login' ? 'current-password' : 'new-password'}
        />
      </label>

      {error && (
        <div role="alert" className="alert alert-error py-2 text-sm">
          {error}
        </div>
      )}

      <button type="submit" className="btn btn-primary" disabled={busy}>
        {busy ? <span className="loading loading-spinner" /> : mode === 'login' ? 'Войти' : 'Создать аккаунт'}
      </button>

      <button
        type="button"
        className="link link-primary text-sm"
        onClick={() => {
          setMode(mode === 'login' ? 'register' : 'login')
          setError('')
        }}
      >
        {mode === 'login' ? 'Нет аккаунта? Зарегистрироваться' : 'Уже есть аккаунт? Войти'}
      </button>
    </form>
  )
}

export default Form
