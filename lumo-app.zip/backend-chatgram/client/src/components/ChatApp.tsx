'use client'
import React, { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { ApiError, api, getToken, setToken } from '@/lib/api'
import { connectSocket, disconnectSocket } from '@/lib/socket'
import { refreshConversations } from '@/lib/actions'
import { useChat } from '@/store/chatStore'
import { Me, Message } from '@/types'
import Sidebar from './Sidebar/Sidebar'
import Messages from './Chat-Threads/Messages'

// Проверяет вход, подключает сокет и раздаёт живые события в хранилище
export default function ChatApp() {
  const router = useRouter()
  const [ready, setReady] = useState(false)
  const [error, setError] = useState('')
  const [attempt, setAttempt] = useState(0)

  useEffect(() => {
    let cancelled = false
    const typingTimers: Record<string, ReturnType<typeof setTimeout>> = {}
    const token = getToken()
    if (!token) {
      router.replace('/')
      return
    }

    async function start(authToken: string) {
      try {
        const me = await api<Me>('/auth/me')
        if (cancelled) return
        useChat.getState().setMe(me)
        await refreshConversations()
        if (cancelled) return

        const socket = connectSocket(authToken)

        socket.on('presence:list', (ids: string[]) => useChat.getState().setOnlineList(ids))
        socket.on('presence:update', (p: { userId: string; online: boolean; lastSeen?: string }) => {
          const st = useChat.getState()
          st.setPresence(p.userId, p.online, p.lastSeen)
          // Появился новый пользователь, которого ещё нет в списке
          if (!st.conversations.some((c) => c.user._id === p.userId)) refreshConversations().catch(() => {})
        })

        socket.on('message:new', (m: Message) => {
          const st = useChat.getState()
          const meId = st.me?._id
          if (!meId) return
          const mine = m.from === meId
          const otherId = mine ? m.to : m.from
          if (st.selectedId === otherId) {
            st.addMessage(m)
            if (!mine) api(`/messages/${otherId}/read`, { method: 'POST' }).catch(() => {})
          }
          if (!st.applyIncoming(m)) refreshConversations().catch(() => {})
        })

        socket.on('messages:read', ({ by }: { by: string }) => useChat.getState().markSentAsRead(by))

        socket.on('typing', ({ from, isTyping }: { from: string; isTyping: boolean }) => {
          clearTimeout(typingTimers[from])
          useChat.getState().setTyping(from, isTyping)
          // Если «перестал печатать» не пришло, сбрасываем сами
          if (isTyping) typingTimers[from] = setTimeout(() => useChat.getState().setTyping(from, false), 4000)
        })

        // После обрыва связи подтягиваем то, что могли пропустить
        socket.io.on('reconnect', () => {
          refreshConversations().catch(() => {})
        })

        setError('')
        setReady(true)
      } catch (e) {
        if (cancelled) return
        if (e instanceof ApiError && e.status === 401) {
          setToken(null)
          router.replace('/')
        } else {
          setError(e instanceof Error ? e.message : 'Не удалось загрузить чаты')
        }
      }
    }

    start(token)

    return () => {
      cancelled = true
      disconnectSocket()
      Object.values(typingTimers).forEach(clearTimeout)
      useChat.getState().reset()
    }
  }, [router, attempt])

  if (error) {
    return (
      <div className="h-[100dvh] flex flex-col gap-4 items-center justify-center p-6 text-center">
        <p>{error}</p>
        <button className="btn btn-primary" onClick={() => setAttempt((n) => n + 1)}>
          Попробовать снова
        </button>
      </div>
    )
  }

  if (!ready) {
    return (
      <div className="h-[100dvh] flex items-center justify-center">
        <span className="loading loading-spinner loading-lg" />
      </div>
    )
  }

  return (
    <div className="h-[100dvh] w-full flex overflow-hidden bg-base-100">
      <Sidebar />
      <Messages />
    </div>
  )
}
