import Image from "next/image";

export default function UserAvatar({
  imageId,
  size = 48,
  online = false,
}: {
  imageId: number;
  size?: number;
  online?: boolean;
}) {
  return (
    <div className={`avatar flex-none ${online ? "online" : ""}`}>
      <div
        className="rounded-full ring ring-primary ring-offset-base-100 ring-offset-1"
        style={{ width: size, height: size }}
      >
        <Image src={`/robohash/${imageId}.png`} alt="" width={256} height={256} />
      </div>
    </div>
  );
}
