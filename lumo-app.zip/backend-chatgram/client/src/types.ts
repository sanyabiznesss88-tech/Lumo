export interface PublicUser {
  _id: string;
  name: string;
  imageId: number;
  lastSeen: string | null;
}

export interface Me extends PublicUser {
  email: string;
}

export interface Message {
  _id: string;
  from: string;
  to: string;
  text: string;
  createdAt: string;
  readAt: string | null;
}

export interface Conversation {
  user: PublicUser;
  last: { text: string; createdAt: string; mine: boolean } | null;
  unread: number;
}
