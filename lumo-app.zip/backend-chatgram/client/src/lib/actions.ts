import { api } from "./api";
import { getSocket } from "./socket";
import { useChat } from "@/store/chatStore";
import { Conversation, Message } from "@/types";

export async function refreshConversations() {
  const list = await api<Conversation[]>("/users");
  useChat.getState().setConversations(list);
}

// Открыть переписку: загрузить историю и отметить входящие прочитанными
export async function openChat(id: string) {
  const st = useChat.getState();
  st.setSelected(id);
  st.setMessages([]);
  st.setLoadingMessages(true);
  try {
    const list = await api<Message[]>(`/messages/${id}`);
    // Пока грузилось, человек мог открыть другой чат
    if (useChat.getState().selectedId !== id) return;
    useChat.getState().setMessages(list);
    useChat.getState().clearUnread(id);
    await api(`/messages/${id}/read`, { method: "POST" });
  } catch {
    /* ошибка загрузки: оставляем пустую переписку */
  } finally {
    if (useChat.getState().selectedId === id) useChat.getState().setLoadingMessages(false);
  }
}

export function closeChat() {
  const st = useChat.getState();
  st.setSelected(null);
  st.setMessages([]);
}

// Отправка через сокет. Само сообщение придёт обратно событием message:new
export function sendMessage(to: string, text: string): Promise<{ ok: boolean; error?: string }> {
  return new Promise((resolve) => {
    const socket = getSocket();
    if (!socket || !socket.connected) return resolve({ ok: false, error: "Нет соединения с сервером" });
    socket.timeout(8000).emit("message:send", { to, text }, (err: unknown, res: any) => {
      if (err) return resolve({ ok: false, error: "Сервер не ответил" });
      resolve(res?.ok ? { ok: true } : { ok: false, error: res?.error || "Не удалось отправить" });
    });
  });
}
