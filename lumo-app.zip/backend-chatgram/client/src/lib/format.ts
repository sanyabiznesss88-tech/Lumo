const pad = (n: number) => String(n).padStart(2, "0");

export function timeOf(iso: string): string {
  const d = new Date(iso);
  return `${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

function sameDay(a: Date, b: Date) {
  return a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate();
}

// Подпись дня над группой сообщений
export function dayLabel(iso: string): string {
  const d = new Date(iso);
  const now = new Date();
  const yesterday = new Date();
  yesterday.setDate(now.getDate() - 1);
  if (sameDay(d, now)) return "Сегодня";
  if (sameDay(d, yesterday)) return "Вчера";
  return d.toLocaleDateString("ru-RU", { day: "numeric", month: "long", year: d.getFullYear() === now.getFullYear() ? undefined : "numeric" });
}

export function isSameDay(a: string, b: string) {
  return sameDay(new Date(a), new Date(b));
}

// Время для списка чатов: сегодня часы и минуты, иначе дата
export function listTime(iso: string): string {
  const d = new Date(iso);
  if (sameDay(d, new Date())) return timeOf(iso);
  return d.toLocaleDateString("ru-RU", { day: "2-digit", month: "2-digit" });
}

export function lastSeenText(iso: string | null): string {
  if (!iso) return "был(а) давно";
  const d = new Date(iso);
  if (sameDay(d, new Date())) return `был(а) в сети в ${timeOf(iso)}`;
  return `был(а) в сети ${d.toLocaleDateString("ru-RU", { day: "numeric", month: "short" })}`;
}
