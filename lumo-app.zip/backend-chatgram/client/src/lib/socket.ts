import { io, Socket } from "socket.io-client";

// Одно подключение на всё приложение
let socket: Socket | null = null;

export function connectSocket(token: string): Socket {
  disconnectSocket();
  socket = io(process.env.NEXT_PUBLIC_SOCKET_URL || "http://localhost:4000", {
    auth: { token },
  });
  return socket;
}

export function getSocket(): Socket | null {
  return socket;
}

export function disconnectSocket() {
  socket?.disconnect();
  socket = null;
}
