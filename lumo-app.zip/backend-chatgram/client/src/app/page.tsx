import Form from '@/components/Login-Page/Form'

export default function Home() {
  return (
    <div className='bg-image bg-cover min-h-[100dvh] w-full flex justify-center items-center p-4'>
      <div className='card w-full max-w-md bg-base-100 rounded-lg'>
        <Form />
      </div>
    </div>
  )
}
