import { create } from "zustand";
import { Conversation, Me, Message } from "@/types";

interface ChatState {
  me: Me | null;
  conversations: Conversation[];
  search: string;
  selectedId: string | null;
  messages: Message[];
  loadingMessages: boolean;
  online: Record<string, boolean>;
  lastSeen: Record<string, string>;
  typing: Record<string, boolean>;

  setMe: (me: Me | null) => void;
  setConversations: (list: Conversation[]) => void;
  setSearch: (q: string) => void;
  setSelected: (id: string | null) => void;
  setMessages: (list: Message[]) => void;
  setLoadingMessages: (v: boolean) => void;
  addMessage: (m: Message) => void;
  applyIncoming: (m: Message) => boolean;
  clearUnread: (otherId: string) => void;
  markSentAsRead: (byId: string) => void;
  setOnlineList: (ids: string[]) => void;
  setPresence: (userId: string, online: boolean, lastSeen?: string) => void;
  setTyping: (userId: string, v: boolean) => void;
  reset: () => void;
}

const initial = {
  me: null,
  conversations: [],
  search: "",
  selectedId: null,
  messages: [],
  loadingMessages: false,
  online: {},
  lastSeen: {},
  typing: {},
};

export const useChat = create<ChatState>((set, get) => ({
  ...initial,

  setMe: (me) => set({ me }),
  setConversations: (conversations) => set({ conversations }),
  setSearch: (search) => set({ search }),
  setSelected: (selectedId) => set({ selectedId }),
  setMessages: (messages) => set({ messages }),
  setLoadingMessages: (loadingMessages) => set({ loadingMessages }),

  // Добавляет сообщение в открытую переписку, повторы по _id игнорируются
  addMessage: (m) =>
    set((s) => (s.messages.some((x) => x._id === m._id) ? s : { messages: [...s.messages, m] })),

  // Обновляет список чатов. Возвращает false, если такого собеседника в списке нет
  applyIncoming: (m) => {
    const { me, conversations, selectedId } = get();
    if (!me) return true;
    const mine = m.from === me._id;
    const otherId = mine ? m.to : m.from;
    const idx = conversations.findIndex((c) => c.user._id === otherId);
    if (idx === -1) return false;
    const c = conversations[idx];
    const updated: Conversation = {
      ...c,
      last: { text: m.text, createdAt: m.createdAt, mine },
      unread: !mine && selectedId !== otherId ? c.unread + 1 : c.unread,
    };
    set({ conversations: [updated, ...conversations.filter((_, i) => i !== idx)] });
    return true;
  },

  clearUnread: (otherId) =>
    set((s) => ({
      conversations: s.conversations.map((c) => (c.user._id === otherId ? { ...c, unread: 0 } : c)),
    })),

  // Собеседник прочитал наши сообщения
  markSentAsRead: (byId) =>
    set((s) => ({
      messages: s.messages.map((m) =>
        m.to === byId && !m.readAt ? { ...m, readAt: new Date().toISOString() } : m
      ),
    })),

  setOnlineList: (ids) => set({ online: Object.fromEntries(ids.map((id) => [id, true])) }),
  setPresence: (userId, online, lastSeen) =>
    set((s) => ({
      online: { ...s.online, [userId]: online },
      lastSeen: lastSeen ? { ...s.lastSeen, [userId]: lastSeen } : s.lastSeen,
    })),
  setTyping: (userId, v) => set((s) => ({ typing: { ...s.typing, [userId]: v } })),

  reset: () => set({ ...initial }),
}));
