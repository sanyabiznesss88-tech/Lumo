/** @type {import('next').NextConfig} */
const API_URL = process.env.API_URL || "http://localhost:4000";

const nextConfig = {
  async rewrites() {
    // Все запросы /api/... клиент отправляет на сервер чата
    return [{ source: "/api/:path*", destination: `${API_URL}/api/:path*` }];
  },
};

module.exports = nextConfig;
