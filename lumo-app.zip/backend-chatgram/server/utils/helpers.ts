import { NextFunction, Request, Response } from "express";

// Express 4 не ловит ошибки в async-обработчиках сам, эта обёртка передаёт их дальше
export const asyncHandler =
  (fn: (req: any, res: Response, next: NextFunction) => Promise<unknown>) =>
  (req: Request, res: Response, next: NextFunction) => {
    Promise.resolve(fn(req, res, next)).catch(next);
  };

// Простое ограничение частоты запросов по IP (хранится в памяти сервера)
export function rateLimit(windowMs: number, max: number) {
  const hits = new Map<string, number[]>();
  return (req: Request, res: Response, next: NextFunction) => {
    const key = req.ip || "unknown";
    const now = Date.now();
    const recent = (hits.get(key) || []).filter((t) => now - t < windowMs);
    if (recent.length >= max) {
      res.status(429).json({ error: "Слишком много попыток, подожди немного" });
      return;
    }
    recent.push(now);
    hits.set(key, recent);
    next();
  };
}
