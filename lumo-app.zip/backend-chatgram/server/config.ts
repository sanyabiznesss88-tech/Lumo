import "dotenv/config";

function need(name: string): string {
  const value = process.env[name];
  if (!value) {
    console.error(`Не задана переменная ${name}. Скопируй .env.example в .env и заполни.`);
    process.exit(1);
  }
  return value;
}

export const config = {
  port: Number(process.env.PORT) || 4000,
  mongoUrl: need("MONGO_URL"),
  jwtSecret: need("JWT_SECRET"),
  // Адреса сайта, которым разрешено обращаться к серверу (через запятую)
  clientOrigins: (process.env.CLIENT_ORIGIN || "http://localhost:3000")
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean),
};
