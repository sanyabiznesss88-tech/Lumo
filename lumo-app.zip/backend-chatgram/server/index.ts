import express, { NextFunction, Request, Response } from "express";
import http from "http";
import cors from "cors";
import morgan from "morgan";
import mongoose from "mongoose";
import { config } from "./config";
import { initSocket } from "./socket";
import authRoutes from "./routes/auth";
import userRoutes from "./routes/users";
import messageRoutes from "./routes/messages";

const app = express();
const server = http.createServer(app);

// Сервер за прокси (Render, Railway): нужно, чтобы ограничитель видел настоящий IP
app.set("trust proxy", 1);

app.use(cors({ origin: config.clientOrigins, credentials: true }));
app.use(express.json({ limit: "20kb" }));
app.use(morgan("tiny"));

app.get("/api/health", (_req, res) => {
  res.json({ ok: true });
});
app.use("/api/auth", authRoutes);
app.use("/api/users", userRoutes);
app.use("/api/messages", messageRoutes);

app.use((_req, res) => {
  res.status(404).json({ error: "Не найдено" });
});

// Любая необработанная ошибка превращается в ответ, а не в падение сервера
app.use((err: unknown, _req: Request, res: Response, _next: NextFunction) => {
  console.error(err);
  res.status(500).json({ error: "Ошибка сервера" });
});

initSocket(server);

async function start() {
  await mongoose.connect(config.mongoUrl);
  console.log("Подключено к MongoDB");
  server.listen(config.port, () => {
    console.log(`Сервер запущен на порту ${config.port}`);
  });
}

start().catch((err) => {
  console.error("Не удалось запустить сервер:", err);
  process.exit(1);
});
