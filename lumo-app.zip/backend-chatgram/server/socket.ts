import http from "http";
import { Server } from "socket.io";
import { Types } from "mongoose";
import { config } from "./config";
import { verifyToken } from "./middleware/auth";
import { User } from "./models/User";
import { Message, publicMessage } from "./models/Message";

let io: Server | null = null;
// userId -> сколько у него сейчас открытых вкладок/устройств
const online = new Map<string, number>();

const room = (userId: string) => `user:${userId}`;

export function emitToUser(userId: string, event: string, payload: unknown) {
  io?.to(room(userId)).emit(event, payload);
}

export function initSocket(server: http.Server) {
  io = new Server(server, {
    cors: { origin: config.clientOrigins, credentials: true },
  });

  // Подключиться может только тот, у кого есть настоящий токен
  io.use((socket, next) => {
    const token = typeof socket.handshake.auth?.token === "string" ? socket.handshake.auth.token : "";
    const userId = token ? verifyToken(token) : null;
    if (!userId) return next(new Error("unauthorized"));
    socket.data.userId = userId;
    next();
  });

  io.on("connection", (socket) => {
    const me = socket.data.userId as string;
    socket.join(room(me));

    const count = (online.get(me) || 0) + 1;
    online.set(me, count);
    if (count === 1) io!.emit("presence:update", { userId: me, online: true });
    socket.emit("presence:list", Array.from(online.keys()));

    // Не больше 20 сообщений за 10 секунд с одного подключения
    let sent: number[] = [];

    socket.on("message:send", async (data: any, ack?: (r: unknown) => void) => {
      const reply = typeof ack === "function" ? ack : () => {};
      try {
        const to = typeof data?.to === "string" ? data.to : "";
        const text = typeof data?.text === "string" ? data.text.trim() : "";
        if (!Types.ObjectId.isValid(to) || to === me) return reply({ ok: false, error: "Неверный получатель" });
        if (!text || text.length > 4000) return reply({ ok: false, error: "Сообщение пустое или слишком длинное" });

        const now = Date.now();
        sent = sent.filter((t) => now - t < 10_000);
        if (sent.length >= 20) return reply({ ok: false, error: "Слишком быстро, подожди пару секунд" });
        sent.push(now);

        if (!(await User.exists({ _id: to }))) return reply({ ok: false, error: "Пользователь не найден" });

        const msg = publicMessage(await Message.create({ from: me, to, text }));
        // Получателю и всем устройствам отправителя
        io!.to(room(to)).to(room(me)).emit("message:new", msg);
        reply({ ok: true, message: msg });
      } catch (err) {
        console.error("message:send", err);
        reply({ ok: false, error: "Не удалось отправить" });
      }
    });

    socket.on("typing", (data: any) => {
      const to = typeof data?.to === "string" ? data.to : "";
      if (!Types.ObjectId.isValid(to)) return;
      emitToUser(to, "typing", { from: me, isTyping: !!data?.isTyping });
    });

    socket.on("disconnect", async () => {
      const left = (online.get(me) || 1) - 1;
      if (left > 0) return void online.set(me, left);
      online.delete(me);
      const lastSeen = new Date();
      try {
        await User.updateOne({ _id: me }, { $set: { lastSeen } });
      } catch (err) {
        console.error("lastSeen", err);
      }
      io!.emit("presence:update", { userId: me, online: false, lastSeen });
    });
  });
}
