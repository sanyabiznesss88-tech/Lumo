import { NextFunction, Request, Response } from "express";
import jwt, { JwtPayload } from "jsonwebtoken";
import { config } from "../config";

export interface AuthRequest extends Request {
  userId?: string;
}

// В токене только id пользователя, больше ничего
export function signToken(userId: string): string {
  return jwt.sign({ id: userId }, config.jwtSecret, { expiresIn: "30d" });
}

export function verifyToken(token: string): string | null {
  try {
    const payload = jwt.verify(token, config.jwtSecret) as JwtPayload | string;
    if (typeof payload === "object" && typeof payload.id === "string") return payload.id;
    return null;
  } catch {
    return null;
  }
}

export function requireAuth(req: AuthRequest, res: Response, next: NextFunction) {
  const header = req.headers.authorization || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : "";
  const userId = token ? verifyToken(token) : null;
  if (!userId) {
    res.status(401).json({ error: "Нужно войти в аккаунт" });
    return;
  }
  req.userId = userId;
  next();
}
