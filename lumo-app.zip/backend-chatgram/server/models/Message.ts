import mongoose, { Schema } from "mongoose";

// Каждое сообщение хранится один раз в своей коллекции
const messageSchema = new Schema(
  {
    from: { type: Schema.Types.ObjectId, ref: "User", required: true },
    to: { type: Schema.Types.ObjectId, ref: "User", required: true },
    text: { type: String, required: true, trim: true, maxlength: 4000 },
    readAt: { type: Date, default: null },
  },
  { timestamps: { createdAt: true, updatedAt: false } }
);

messageSchema.index({ from: 1, to: 1, createdAt: -1 });
messageSchema.index({ to: 1, from: 1, createdAt: -1 });

export const Message = mongoose.model("Message", messageSchema, "cg_messages");

export function publicMessage(m: {
  _id: unknown;
  from: unknown;
  to: unknown;
  text: string;
  createdAt?: Date;
  readAt?: Date | null;
}) {
  return {
    _id: String(m._id),
    from: String(m.from),
    to: String(m.to),
    text: m.text,
    createdAt: m.createdAt ?? new Date(),
    readAt: m.readAt ?? null,
  };
}
