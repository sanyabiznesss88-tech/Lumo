import mongoose, { Schema, InferSchemaType } from "mongoose";

const userSchema = new Schema(
  {
    name: { type: String, required: true, trim: true, minlength: 2, maxlength: 32 },
    email: { type: String, required: true, unique: true, lowercase: true, trim: true },
    // Хэш пароля никогда не попадает в обычные запросы
    passwordHash: { type: String, required: true, select: false },
    imageId: { type: Number, default: 0, min: 0, max: 5 },
    lastSeen: { type: Date, default: Date.now },
  },
  { timestamps: true }
);

export type UserDoc = InferSchemaType<typeof userSchema> & { _id: mongoose.Types.ObjectId };

// Новая коллекция: старая chatgram_users хранила сообщения внутри пользователей
export const User = mongoose.model("User", userSchema, "cg_users");

export function publicUser(u: { _id: unknown; name: string; imageId?: number | null; lastSeen?: Date | null }) {
  return {
    _id: String(u._id),
    name: u.name,
    imageId: u.imageId ?? 0,
    lastSeen: u.lastSeen ?? null,
  };
}
