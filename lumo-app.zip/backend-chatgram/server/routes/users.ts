import { Router } from "express";
import { Types } from "mongoose";
import { User, publicUser } from "../models/User";
import { Message } from "../models/Message";
import { AuthRequest, requireAuth } from "../middleware/auth";
import { asyncHandler } from "../utils/helpers";

const router = Router();

function escapeRegex(s: string) {
  return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

// Список собеседников: последнее сообщение и число непрочитанных.
// Почту других пользователей не отдаём.
router.get(
  "/",
  requireAuth,
  asyncHandler(async (req: AuthRequest, res) => {
    const me = new Types.ObjectId(req.userId);
    const q = typeof req.query.q === "string" ? req.query.q.trim().slice(0, 32) : "";

    const filter: Record<string, unknown> = { _id: { $ne: me } };
    if (q) filter.name = { $regex: escapeRegex(q), $options: "i" };
    const users = await User.find(filter).limit(200);

    const convs = await Message.aggregate([
      { $match: { $or: [{ from: me }, { to: me }] } },
      { $sort: { createdAt: -1 } },
      {
        $group: {
          _id: { $cond: [{ $eq: ["$from", me] }, "$to", "$from"] },
          last: { $first: "$$ROOT" },
          unread: {
            $sum: {
              $cond: [{ $and: [{ $eq: ["$to", me] }, { $eq: ["$readAt", null] }] }, 1, 0],
            },
          },
        },
      },
    ]);
    const byId = new Map<string, any>(convs.map((c) => [String(c._id), c]));

    const items = users.map((u) => {
      const c = byId.get(String(u._id));
      return {
        user: publicUser(u),
        last: c
          ? {
              text: c.last.text as string,
              createdAt: c.last.createdAt as Date,
              mine: String(c.last.from) === req.userId,
            }
          : null,
        unread: c ? (c.unread as number) : 0,
      };
    });

    // Сначала те, с кем уже переписывались (свежие выше), потом остальные по имени
    items.sort((a, b) => {
      if (a.last && b.last) return +new Date(b.last.createdAt) - +new Date(a.last.createdAt);
      if (a.last) return -1;
      if (b.last) return 1;
      return a.user.name.localeCompare(b.user.name);
    });

    res.json(items);
  })
);

export default router;
