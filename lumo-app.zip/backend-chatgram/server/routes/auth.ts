import { Router } from "express";
import bcrypt from "bcryptjs";
import { User, publicUser } from "../models/User";
import { AuthRequest, requireAuth, signToken } from "../middleware/auth";
import { asyncHandler, rateLimit } from "../utils/helpers";

const router = Router();
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const limiter = rateLimit(15 * 60 * 1000, 30);

function str(v: unknown): string {
  return typeof v === "string" ? v : "";
}

router.post(
  "/register",
  limiter,
  asyncHandler(async (req, res) => {
    const name = str(req.body.name).trim();
    const email = str(req.body.email).trim().toLowerCase();
    const password = str(req.body.password);
    const imageId = Number.isInteger(req.body.imageId) ? Number(req.body.imageId) : 0;

    if (name.length < 2 || name.length > 32) {
      return res.status(400).json({ error: "Имя должно быть от 2 до 32 символов" });
    }
    if (!EMAIL_RE.test(email)) {
      return res.status(400).json({ error: "Введи настоящий email" });
    }
    // bcrypt учитывает только первые 72 байта пароля
    if (password.length < 6 || password.length > 72) {
      return res.status(400).json({ error: "Пароль должен быть от 6 до 72 символов" });
    }
    if (imageId < 0 || imageId > 5) {
      return res.status(400).json({ error: "Неверный аватар" });
    }

    if (await User.exists({ email })) {
      return res.status(409).json({ error: "Этот email уже зарегистрирован" });
    }

    const passwordHash = await bcrypt.hash(password, 10);
    try {
      const user = await User.create({ name, email, passwordHash, imageId });
      res.status(201).json({
        token: signToken(String(user._id)),
        user: { ...publicUser(user), email: user.email },
      });
    } catch (err: any) {
      // Два одинаковых запроса одновременно
      if (err?.code === 11000) {
        return res.status(409).json({ error: "Этот email уже зарегистрирован" });
      }
      throw err;
    }
  })
);

router.post(
  "/login",
  limiter,
  asyncHandler(async (req, res) => {
    const email = str(req.body.email).trim().toLowerCase();
    const password = str(req.body.password);
    const user = await User.findOne({ email }).select("+passwordHash");
    const ok = user ? await bcrypt.compare(password, user.passwordHash) : false;
    if (!user || !ok) {
      return res.status(401).json({ error: "Неверный email или пароль" });
    }
    res.json({
      token: signToken(String(user._id)),
      user: { ...publicUser(user), email: user.email },
    });
  })
);

router.get(
  "/me",
  requireAuth,
  asyncHandler(async (req: AuthRequest, res) => {
    const user = await User.findById(req.userId);
    if (!user) return res.status(401).json({ error: "Аккаунт не найден" });
    res.json({ ...publicUser(user), email: user.email });
  })
);

export default router;
