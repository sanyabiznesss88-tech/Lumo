import { Router } from "express";
import { Types } from "mongoose";
import { Message, publicMessage } from "../models/Message";
import { AuthRequest, requireAuth } from "../middleware/auth";
import { asyncHandler } from "../utils/helpers";
import { emitToUser } from "../socket";

const router = Router();
router.use(requireAuth);

// История переписки с одним человеком (только своя), последние 50 сообщений
router.get(
  "/:userId",
  asyncHandler(async (req: AuthRequest, res) => {
    const other = req.params.userId;
    if (!Types.ObjectId.isValid(other)) {
      return res.status(400).json({ error: "Неверный id" });
    }
    const me = new Types.ObjectId(req.userId);
    const them = new Types.ObjectId(other);

    const filter: Record<string, unknown> = {
      $or: [
        { from: me, to: them },
        { from: them, to: me },
      ],
    };
    // Для подгрузки более старых сообщений
    if (typeof req.query.before === "string" && !isNaN(Date.parse(req.query.before))) {
      filter.createdAt = { $lt: new Date(req.query.before) };
    }

    const list = await Message.find(filter).sort({ createdAt: -1 }).limit(50);
    res.json(list.reverse().map(publicMessage));
  })
);

// Пометить входящие от этого человека как прочитанные
router.post(
  "/:userId/read",
  asyncHandler(async (req: AuthRequest, res) => {
    const other = req.params.userId;
    if (!Types.ObjectId.isValid(other)) {
      return res.status(400).json({ error: "Неверный id" });
    }
    const result = await Message.updateMany(
      { from: new Types.ObjectId(other), to: new Types.ObjectId(req.userId), readAt: null },
      { $set: { readAt: new Date() } }
    );
    if (result.modifiedCount > 0) {
      emitToUser(other, "messages:read", { by: req.userId });
    }
    res.json({ ok: true });
  })
);

export default router;
